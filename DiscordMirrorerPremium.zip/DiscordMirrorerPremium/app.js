import Eris from "eris";

const client = new Eris("TOKEN");

let channel_object = [
  {
    channel_id: "885527606420709446",
    webhook_url:
      "https://discord.com/api/webhooks/891078396052914257/scKhVADjYZK5EE1I-UOr3lvOg0oNdop4hj4rssvJkwOTkDytpq5TF4qqPu5DfVsWmrgy",
  },
  {
    channel_id: "807517007956279297",
    webhook_url:
      "https://discord.com/api/webhooks/882887632374362143/mlNDVa6oVceNPcdplcJqdEHYjUPnGmPsRkQaXdfrUVNu2kuVYBwe2MXp-itP6UcNw1x6",
  },
];

client.on("messageCreate", async (m) => {
  let channel = channel_object.find(
    (object) => object.channel_id === m.channel.id
  );
  if (channel?.webhook_url) {
    let attachments = m.attachments[0]?.url || "";

    let webhook = {
      username: m.author.username,
      avatarURL: `https://cdn.discordapp.com/avatars/${m.author.id}/${m.author.avatar}.png?size=256`,
      content: m.content + " " + attachments,
    };
    if (m.embeds[0]) {
      webhook.embeds = [m.embeds[0]];
    }
    try {
      let webhookid = channel.webhook_url.split("webhooks/")[1].split("/")[0];
      let webhookToken = channel.webhook_url
        .split("webhooks/")[1]
        .split("/")[1];
      client.executeWebhook(webhookid, webhookToken, webhook);
      console.log(
        `Sent content by ${m.author.username} from ${m.channel.id} to ${channel.webhook_url}`
      );
    } catch (e) {
      console.log(e);
    }
  }
});

try {
  client.connect();
} catch {}
